// ============================================================
//  SITE DATA — barcha shaxsiy ma'lumotlar SHU YERDA tahrirlanadi.
//  Qiymat bo'sh ('' yoki []) bo'lsa, saytda aniq belgilangan
//  placeholder ko'rinadi. Hech narsa o'ylab topilmagan.
// ============================================================

export const profile = {
  name: '[YOUR NAME]',
  initials: '[YI]', // masalan: 'BB'
  profession: '[YOUR PROFESSION]',
  intro: '[YOUR INTRODUCTION]',
  age: '[YOUR AGE]',
  location: '[YOUR LOCATION]',
  experience: '[YOUR EXPERIENCE]',
  skillsSummary: '[YOUR SKILLS]',
  bio: '[WRITE ABOUT YOURSELF]',
  goals: '[YOUR GOALS]',
  photo: '', // masalan: '/photo.jpg'  (rasmni public/ papkasiga qo'ying)
}

export const contacts = {
  email: '', // '[YOUR EMAIL]'  -> masalan: 'you@mail.com'
  telegram: '', // masalan: 'https://t.me/username'
  github: '', // masalan: 'https://github.com/username'
  linkedin: '', // masalan: 'https://linkedin.com/in/username'
  instagram: '', // masalan: 'https://instagram.com/username'
}

export const contactPlaceholders = {
  email: '[YOUR EMAIL]',
  telegram: '[YOUR TELEGRAM]',
  github: '[YOUR GITHUB]',
  linkedin: '[YOUR LINKEDIN]',
  instagram: '[YOUR INSTAGRAM]',
}

// Kontakt forma haqiqatan yuborishi uchun Formspree (yoki shunga o'xshash)
// endpoint kiriting, masalan: 'https://formspree.io/f/xxxxxxx'
// Bo'sh qolsa — forma halol rejimda ishlaydi (xabar yuborilmaydi, buni aytadi).
export const FORM_ENDPOINT = ''

// Skills: level ataylab yo'q — foizlar o'ylab topilmaydi.
// "note" ni o'zingiz yozing, masalan: '2 yillik tajriba'.
export const skills = [
  { name: 'HTML5', note: '[NOTE]' },
  { name: 'CSS3', note: '[NOTE]' },
  { name: 'JavaScript', note: '[NOTE]' },
  { name: 'React', note: '[NOTE]' },
  { name: 'Tailwind CSS', note: '[NOTE]' },
  { name: 'UI/UX Design', note: '[NOTE]' },
  { name: 'Responsive Web Design', note: '[NOTE]' },
  { name: 'Animation', note: '[NOTE]' },
  { name: '3D Web Development', note: '[NOTE]' },
]

export const experienceBlocks = [
  { key: 'experience', title: 'Experience', placeholder: '[EXPERIENCE]', items: [] },
  { key: 'achievements', title: 'Achievements', placeholder: '[ACHIEVEMENTS]', items: [] },
  { key: 'certificates', title: 'Certificates', placeholder: '[CERTIFICATES]', items: [] },
  { key: 'education', title: 'Education', placeholder: '[EDUCATION]', items: [] },
]
// items namuna: [{ title: 'Frontend Developer', meta: '2025 — hozir', text: 'Qisqa tavsif' }]

const blank = (n) => {
  const num = String(n).padStart(2, '0')
  return {
    id: n,
    number: num,
    name: '',
    description: '',
    url: '', // Live sayt manzili
    github: '', // ixtiyoriy
    image: '', // masalan: '/projects/01.jpg'
    tech: [], // masalan: ['React', 'Tailwind']
    category: '',
    placeholders: {
      name: `[PROJECT ${num} NAME]`,
      description: `[PROJECT ${num} DESCRIPTION]`,
      url: `[PROJECT ${num} URL]`,
      image: `[PROJECT ${num} IMAGE]`,
      tech: '[TECH STACK]',
      category: '[CATEGORY]',
    },
  }
}

// Aniq 13 ta loyiha. Har birini alohida to'ldiring.
export const projects = [
  { ...blank(1) },
  { ...blank(2) },
  { ...blank(3) },
  { ...blank(4) },
  { ...blank(5) },
  { ...blank(6) },
  { ...blank(7) },
  { ...blank(8) },
  { ...blank(9) },
  { ...blank(10) },
  { ...blank(11) },
  { ...blank(12) },
  { ...blank(13) },
]

export const navItems = [
  { id: 'home', label: 'Home' },
  { id: 'about', label: 'About' },
  { id: 'projects', label: 'Projects' },
  { id: 'skills', label: 'Skills' },
  { id: 'experience', label: 'Experience' },
  { id: 'contact', label: 'Contact' },
]
