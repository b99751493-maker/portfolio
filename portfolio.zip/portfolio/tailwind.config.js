/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        midnight: '#07090a',
        coal: '#0d1112',
        ivory: '#f4efe4',
        lime: '#c6ff3d',
        emerald: '#0f6b4f',
        silver: '#9aa3a6',
        chrome: '#d9dfe1',
        ember: '#ff7a2f',
      },
      fontFamily: {
        display: ['"Space Grotesk"', 'system-ui', 'sans-serif'],
        serif: ['"Instrument Serif"', 'Georgia', 'serif'],
        mono: ['"JetBrains Mono"', 'ui-monospace', 'monospace'],
      },
      boxShadow: {
        glow: '0 0 60px -10px rgba(198,255,61,0.35)',
      },
    },
  },
  plugins: [],
}
